package com.example.aplikasiuts1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
